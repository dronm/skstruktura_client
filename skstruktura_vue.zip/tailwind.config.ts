export default {
	content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
	theme: {
		extend: {
		  fontFamily: {
			sans: ['Calibri', 'sans-serif'],
		  },
		},
	},
	plugins: [],
};
