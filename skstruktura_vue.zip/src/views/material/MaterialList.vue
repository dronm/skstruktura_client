<script setup lang="ts">
import { CollectionListPage } from "@katren/vue-collection-lib";

import { materialCollection } from "@/collections/material.gen";
</script>

<template>
	<CollectionListPage :collection="materialCollection" />
</template>
